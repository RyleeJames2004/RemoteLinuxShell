ls
mkdir assign1
ls
cd assign1/
gcc assignment1.c
./assign1
gcc assignment1.c
ls
./a.out
gcc assignment1.c -o assign1
ls
./assign1
clear
gcc assignment1.c -o assign1
./assign1
cd assign1
gcc assignment1.c
./assign1
mkdir assignment2
ls
cd assignment2
ls
gcc assignment2.c -o assign2
ls
./assign2
gcc myshell.c -o myshell
./myshell
clear
./myshell
clear
./myshell
clear
./myshell
ls
./myshell
gcc myShell.c -o myShell
pwd
gcc myshell.c -o myshell
./myshell
sort 2> error_log.txt
ls
cat error_log.txt
rm file.txt 2> error_log.txt
cat error_log.txt
sort < 
ls > 
logout
exit
ls
cat file.txt | grep "error" 2> error_log.txt
cat error_log.txt
cat file.txt | grep "error" | wc -l 2> error.txt
cat error.txt
exit
